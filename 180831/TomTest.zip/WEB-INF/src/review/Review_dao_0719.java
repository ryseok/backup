package review;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import iba.MySqlMapClient;

public class Review_dao_0719 {
	SqlMapClient smc; //XML내의 sql문 호출
	
	public Review_dao_0719() {
		smc = MySqlMapClient.getSqlMapInstance();
	}
	
	 /*
	   public boolean 또는 String insert(빈즈) {}
	   public boolean 또는 String update(빈즈) {}
	   public boolean 또는 String delete(프라이머리키) {}
	   public 빈즈 select(프라이머리키) {}//수정폼
	   public ArrayList<빈즈> selectAll() {}
	 */
	
	public boolean insert(Review_vo_0719 review) {
		try {
			smc.insert("review.insert",review);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
	
	public boolean update(Review_vo_0719 review) {
		return false;
		
	}
	
	public boolean delete(Review_vo_0719 review) {
		return false;
		
	}
	
	public Review_vo_0719 update(int no) {
		Review_vo_0719 review = null;
		return review;
		
	}
	
	public List<Review_vo_0719> selectAll(){
		List<Review_vo_0719> list = null;
		
		return list;
		
	}
}
