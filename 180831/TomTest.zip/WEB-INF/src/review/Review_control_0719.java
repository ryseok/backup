package review;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/review/control")
public class Review_control_0719 extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		System.out.println("action===>" + action);
		Review_dao_0719 dao = new Review_dao_0719();

		if (action == null || action.equals("list")) {
			request.setAttribute("list", dao.selectAll());

			request.getRequestDispatcher("/review/list.jsp").forward(request, response);
		} else if (action.equals("insert")) {// 1. DB입력요청
			// 2. 입력폼내의 데이터 얻어오기
			String writer = request.getParameter("writer");
			String email = request.getParameter("email");
			String tel = request.getParameter("tel");
			String pass = request.getParameter("pass");
			String contents = request.getParameter("contents");

			Review_vo_0719 review = new Review_vo_0719();
			// new Guest(0, writer, email, tel, pass, contents, null);
			review.setWriter(writer);
			review.setEmail(email);
			review.setTel(tel);
			review.setPass(pass);
			review.setContents(contents);

			// 3. DAO객체생성, 호출
			if (dao.insert(review)) {
				// 4. 페이지 이동 (행추가를 반영한 list.jsp보이기)
				response.sendRedirect("control?action=list");
			}
		}
	}

}
