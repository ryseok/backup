package review;

import java.sql.Date;

public class Review_vo_0719 {
	// 보안상 private 사용
	// 여기에서만 사용 할꺼
	private int no; 			// 번호
	private String writer; 		// 작성자
	private String email; 		// 이메일
	private String tel; 		// 전화번호
	private String pass; 		// 비빌번호
	private String contents; 	// 방명록 작성 칸
	private Date wdate; 		// 날짜
	
	
	public Review_vo_0719() {
		// TODO Auto-generated constructor stub
	}

	public Review_vo_0719(int no, String writer, String email, String tel, String pass, String contents, Date wdate) {
		super();
		this.no = no;
		this.writer = writer;
		this.email = email;
		this.tel = tel;
		this.pass = pass;
		this.contents = contents;
		this.wdate = wdate;
	}

	@Override
	public String toString() {
		return "Review_vo_0719 [no=" + no + ", writer=" + writer + ", email=" + email + ", tel=" + tel + ", pass="
				+ pass + ", contents=" + contents + ", wdate=" + wdate + "]";
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public Date getWdate() {
		return wdate;
	}

	public void setWdate(Date wdate) {
		this.wdate = wdate;
	}
	
	
}
