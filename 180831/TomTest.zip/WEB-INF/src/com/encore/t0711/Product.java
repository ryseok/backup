package com.encore.t0711;

public class Product {
	String []productList = {"item1","item2","item3","item4","item5"};

	public String[] getProductList() {
		return productList;
	}

}
