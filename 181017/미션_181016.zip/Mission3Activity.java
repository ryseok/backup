package com.encore.mission;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

public class Mission3Activity extends AppCompatActivity {
    ImageView imageView1;
    ImageView imageView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);//뷰엘리먼트에 대한 객체생성과 메모리 로딩!!
        imageView1 =  findViewById(R.id.imageView1);
        imageView2 =  findViewById(R.id.imageView2);
    }

    //버튼이벤트 처리
    public void onButtonClicked(View v){
        Log.i("ID", "getId:"+v.getId()+", up버튼:"+ R.id.bt_up+
                ", down버튼:"+R.id.bt_down);
        if(v.getId() == R.id.bt_down){//bt_down클릭
            imageView2.setImageResource(R.drawable.image01);//add
            imageView1.setImageResource(0);//remove
        }else{//bt_up클릭
            imageView1.setImageResource(R.drawable.image01);//add
            imageView2.setImageResource(0);//remove
        }

    }
}
