package com.localup.domain;

public class TestVO {
   private String su;

public String getSu() {
	return su;
}

public void setSu(String su) {
	this.su = su;
}
   
}
