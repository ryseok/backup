package com.localup.persistence;

public class MemberDAOImpl_sign implements MemberDAO_sign{

}
