package com.localup.service;

public interface MemberService_sign {

}
