package com.localup.service;

public class MemberServiceImpl_sign implements MemberService_sign{

}
