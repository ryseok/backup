package com.localup.persistence;

public interface MemberDAO_sign {
}
