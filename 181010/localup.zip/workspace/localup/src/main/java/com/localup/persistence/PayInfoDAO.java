package com.localup.persistence;

import com.localup.domain.PayInfoVO;

public interface PayInfoDAO {
	public void insert(PayInfoVO payInfoVO) throws Exception;
}
