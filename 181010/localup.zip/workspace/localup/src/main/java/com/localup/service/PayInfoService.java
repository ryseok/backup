package com.localup.service;

import com.localup.domain.PayInfoVO;

public interface PayInfoService {
	public void insert(PayInfoVO payInfoVO) throws Exception;
}
