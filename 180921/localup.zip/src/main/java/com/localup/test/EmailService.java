package com.localup.test;

public interface EmailService {
	public void create(EmailForm emailForm) throws Exception;
	
	public void update(EmailForm emailForm) throws Exception;
}
