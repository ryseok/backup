package com.localup.test;

public interface UserService {
	public Object login(UserVO uservo) throws Exception;
}
