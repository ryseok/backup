package com.localup.test;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class LoginControl {
	
	@Inject
	private UserService userService;
	
	// 로그인 입력폼
	@RequestMapping("login")
	public String loginGET(UserVO userVO) throws Exception {
		userService.login(userVO);
		return "test/login";
	}//loginGET

	// 로그인 성공폼
	@RequestMapping("success2")
	public String success2POST() throws Exception {
		return "test/success2";
	}//success2
}// main
