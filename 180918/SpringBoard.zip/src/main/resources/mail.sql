create table userAuth(
userEmail varchar2(50),
authKey varchar2(50)
);